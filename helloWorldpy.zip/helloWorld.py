"""
Developer: Jorge Chavarria
Date: January 10, 2026
Purpose: This program demonstrates basic Python output by printing "Hello, World!"
"""

# Print a simple message to the console
print("Hello, World!")